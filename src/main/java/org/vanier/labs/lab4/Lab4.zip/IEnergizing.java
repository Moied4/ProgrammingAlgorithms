package org.vanier.labs.lab4;

/**
 * Interface for energy-related operations (fueling or charging).
 */
public interface IEnergizing {
    void getEnergy();
}
