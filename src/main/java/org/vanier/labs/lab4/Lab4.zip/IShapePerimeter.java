package org.vanier.labs.lab4;


/**
 * Interface for shape perimeter calculation.
 */
public interface IShapePerimeter {
    double calculatePerimeter();
}
