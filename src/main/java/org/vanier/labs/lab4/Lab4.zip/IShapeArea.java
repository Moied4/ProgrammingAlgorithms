package org.vanier.labs.lab4;


/**
 * Interface for shape area calculation.
 */
public interface IShapeArea {
    double calculateArea();
}

